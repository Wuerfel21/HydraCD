 *********************************
 *   Rem Alien Invader game v013 *
 *********************************

 This game uses REM_alien_data_***.spin for tilemap and tiles asset
 Also uses REM_gfx_engine_***.spin: The REM graphic engine
 And REM_tv_***.spin: REM graphic engine TV rasteriser

 It features 16 sprites, two player actions with gamepad and keyboard controls.
 Keyboard is mapped to:
   player 1: W,A,S,D with left control/alt/shift to shoot
   player 2: Arrows with right control/alt/shift to shoot

 Credits:
 
 Almost all graphic asset made by Louis-Philippe 'FoX' Guilbert
 Programmed by Remi 'Remz' Veilleux

