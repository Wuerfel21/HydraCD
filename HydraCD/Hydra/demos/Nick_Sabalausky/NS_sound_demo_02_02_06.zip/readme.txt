NS_sound_demo_02_02_06
=======================

3 files:
NS_sound_demo_010.spin (Top File): A demonstration of my sound driver. Makes a slowly sweeping sine wave.
NS_sound_drv_010.spin: My sound driver.
readme.txt: This readme file.

Note: This has no video output, so make sure you either hook up 
      the Hydra's audio to a stereo or speaker, or feed your TV
      a valid video signal from a VCR/DVD/game system/etc.
      Otherwise, your TV might not play the audio.
