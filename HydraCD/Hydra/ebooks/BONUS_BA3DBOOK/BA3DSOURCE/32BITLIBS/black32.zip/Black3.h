
// Header file for chapter 3 - BLACK3.H

// D E F I N E S /////////////////////////////////////////////////////////////

#define GRAPHICS_MODE13     0x13  // 320x200x256
#define TEXT_MODE           0x03  // 80x25 text mode

#define COLOR_MASK        0x3C6 // the bit mask register
#define COLOR_REGISTER_RD 0x3C7 // set read index at this I/O
#define COLOR_REGISTER_WR 0x3C8 // set write index at this I/O
#define COLOR_DATA        0x3C9 // the R/W data is here

#define ROM_CHAR_SET_SEG 0xF000   // segment of 8x8 ROM character set
#define ROM_CHAR_SET_OFF 0xFA6E   // begining offset of 8x8 ROM character set

#define ROM_CHAR_WIDTH      8     // width of ROM 8x8 character set in pixels
#define ROM_CHAR_HEIGHT     8     // height of ROM 8x8 character set in pixels

#define MODE13_WIDTH   320 // mode 13h screen dimensions
#define MODE13_HEIGHT  200


// M A C R O S ///////////////////////////////////////////////////////////////

#define SET_BITS(x,bits)   (x | bits)
#define RESET_BITS(x,bits) (x & ~bits)

// S T R U C T U R E S ///////////////////////////////////////////////////////

// this structure holds a RGB triple in three unsigned bytes

typedef struct RGB_color_typ
        {

        unsigned char red;    // red   component of color 0-63
        unsigned char green;  // green component of color 0-63
        unsigned char blue;   // blue  component of color 0-63

        } RGB_color, *RGB_color_ptr;

// this structure holds an entire color palette

typedef struct RGB_palette_typ
        {
        int start_reg;   // index of the starting register that is save
        int end_reg;     // index of the ending registe that is saved

        RGB_color colors[256];   // the storage area for the palette

        } RGB_palette, *RGB_palette_ptr;

// P R O T O T Y P E S ///////////////////////////////////////////////////////

void Print_Char(int xc,int yc,char c,int color,int transparent);

void Print_String(int x,int y,int color, char *string,int transparent);

void Write_Pixel(int x,int y,int color);

int Read_Pixel(int x,int y);

void Set_Graphics_Mode(int mode);

void Time_Delay(int clicks);

void Line_H(int x1,int x2,int y,int color);

void Line_V(int y1,int y2,int x,int color);

void Write_Color_Reg(int index, RGB_color_ptr color);

void Read_Palette(int start_reg,int end_reg, RGB_palette_ptr the_palette);

void Write_Palette(int start_reg,int end_reg, RGB_palette_ptr the_palette);

RGB_color_ptr Read_Color_Reg(int index, RGB_color_ptr color);

void Draw_Rectangle(int x1,int y1,int x2,int y2,int color);

void Fill_Screen(int color);


// G L O B A L S /////////////////////////////////////////////////////////////

extern unsigned char *video_buffer;   // video ram byte ptr
extern unsigned char *rom_char_set;   // rom characters 8x8


