
// P R O T O T Y P E S ///////////////////////////////////////////////////////

extern "C"
{

void _quadcpy32(void *dest, const void *source,int length);
void _wordcpy32(void *dest, const void *source,int length);
void _quadset32(void *dest, int data, int length);
void _wordset32(void *dest, int data, int length);

} // end all external C functions
