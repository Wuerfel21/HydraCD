
// I N C L U D E S ///////////////////////////////////////////////////////////

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include <i86.h>
#include <conio.h>
#include <io.h>
#include <time.h>
#include <bios.h>
#include <dos.h>
#include "32bit.h"

// include all of our stuff

#include "black3.h"
#include "black4.h"
#include "black5.h"
#include "black8.h"

// D E F I N E S /////////////////////////////////////////////////////////////

// constants used to represent angles for the ray casting a 60 degree field of
// view

#define ANGLE_0        0
#define ANGLE_5        20   // 5.625
#define ANGLE_11       40   // 1.25
#define ANGLE_22       80   // 22.5
#define ANGLE_45       160
#define ANGLE_90       320
#define ANGLE_180      640
#define ANGLE_360      1280

// there are 1920 degrees in our circle or 360/(320*360/fov) is the conversion factor
// from real degrees to our degrees

#define ANGULAR_INCREMENT  ((float)0.28125)

// conversion constants from radians to degrees and vicversa

#define DEG_TO_RAD         ((float)3.1415926/(float)180)
#define RAD_TO_DEG         ((float)180/(float)3.1415926)

// G L O B A L S  ////////////////////////////////////////////////////////////

pcx_picture image_pcx;           // general pcx image

int play_x=1000,                 // the current world x of player
    play_y=1000,                 // the current world y of player

    play_height=100,
    play_ang=ANGLE_0,            // the current viewing angle of player
    play_dist = 64;

float play_dir_x,                // the direction the player is pointing in
      play_dir_y,
      cos_look[ANGLE_360],       // cosine look up table
      sin_look[ANGLE_360],       // sin look up table
      sphere_cancel[ANGLE_90+1]; // cancels fish eye distortion

// F U N C T I O N S ////////////////////////////////////////////////////////

int Initialize(char *filename)
{
// this function builds all the look up tables for the terrain generator and
// loads in the terrain texture map

int ang;           // looping variable

float rad_angle;   // current angle in radians

// create sin and cos look up first

for (ang=0; ang<ANGLE_360; ang++)
    {
    // compute current angle in radians

    rad_angle = (float)ang*ANGULAR_INCREMENT*DEG_TO_RAD;

    // now compute the sin and cos

    sin_look[ang] = sin(rad_angle);
    cos_look[ang] = cos(rad_angle);

    } // end for ang

// create inverse cosine viewing distortion filter

for (ang=0; ang<=ANGLE_45; ang++)
    {
    // compute current angle in radians

    rad_angle = (float)ang*ANGULAR_INCREMENT*DEG_TO_RAD;

    // now compute the sin and cos

    sphere_cancel[ang+ANGLE_45] = 1/cos(rad_angle);
    sphere_cancel[ANGLE_45-ang] = 1/cos(rad_angle);

    } // end for ang

// intialize the pcx structure

PCX_Init((pcx_picture_ptr)&image_pcx);

// load in the textures

return(PCX_Load(filename, (pcx_picture_ptr)&image_pcx,1));

} // end Initialize

/////////////////////////////////////////////////////////////////////////////

void Draw_Terrain(int play_x,
                  int play_y,
                  int play_height,
                  int play_ang,
                  int play_dist)
{
// this function draws the entire terrain based on the location and orientation
// of the player's viewpoint

int xr,yr,          // location of ray in world coords
    x_fine,y_fine,  // the texture coordinates the ray hit
    row,            // the current video row begin processed
    row_inv,        // the inverted row to make upward positive
    start_row=32000,
    left_ang,
    right_ang;

unsigned char *screen_ptr,
              *texture_ptr;

unsigned char pixel_color;    // the color of textel

float ray_length,   // the length of the ray after distortion compensation
      xs,ys,
      xe,ye,
      dx,dy;

int xsf,ysf,
    xef,yef,
    dxf,dyf;

// start the current angle off -30 degrees to the left of the player's
// current viewing direction

left_ang  = play_ang - ANGLE_45;
right_ang = left_ang + ANGLE_90;

// test for underflow

if (left_ang < 0)
   left_ang+=ANGLE_360;

if (right_ang >= ANGLE_360)
   right_ang-=ANGLE_360;

    // point screen pointer to starting video line

    screen_ptr = double_buffer + start_row;

    // point texture pointer to texture

    texture_ptr = image_pcx.buffer;

    // for each column compute the pixels that should be displayed
    // for each screen pixel, process from top to bottom

    for (row = 100; row<200; row++)
        {
        // compute length of ray

        row_inv = 200-row;

        // compute starting point

        // use the current height and distance to compute length of ray.

        ray_length = sphere_cancel[0] * ((float)(play_dist*play_height)/
                                         (float)(play_height-row_inv));

        // rotate ray into position of sample

        xs = ((float)play_x + ray_length * cos_look[left_ang]);
        ys = ((float)play_y - ray_length * sin_look[left_ang]);

        xsf = xs*(262144);
        ysf = ys*(262144);

        // compute ending point

        // use the current height and distance to compute length of ray.

        ray_length = sphere_cancel[319] * ((float)(play_dist*play_height)/
                                           (float)(play_height-row_inv));

        // rotate ray into position of sample

        xe = ((float)play_x + ray_length * cos_look[right_ang]);
        ye = ((float)play_y - ray_length * sin_look[right_ang]);

        xef = xe*(262144);
        yef = ye*(262144);

        // compute deltas

        dx = (xe-xs)/(float)320;
        dy = (ye-ys)/(float)320;

        dxf = dx*(262144);
        dyf = dy*(262144);

        // now loop across row and draw pixels

        for (xr=0; xr<320; xr++)
            {
            // compute texture coords

            x_fine = ((xsf >> 18) & 0x3f);
            y_fine = ((ysf >> 18) & 0x3f);

            // plot the pixel

            // using texture index locate texture pixel in textures

            pixel_color = texture_ptr[x_fine + (y_fine << 8) + (y_fine << 6)];

            // draw the textel

            *screen_ptr = (unsigned char)pixel_color;

            // move to next grid position

            xsf+=dxf;
            ysf+=dyf;

            // increment screen pointer

            screen_ptr++;

            } // end for

        } // end for row

} // end Draw_Terrain

// M A I N //////////////////////////////////////////////////////////////////

void main(int argc, char **argv)
{
char buffer[80];

int done=0, // exit flag
    num_frames=0;

float speed=0;  // speed of player

// check to see if command line parms are correct

if (argc<=1)
   {
   // not enough parms

   printf("\nUsage: voxel.exe filename.pcx ");
   printf("\nExample: voxel voxterr4.pcx \n");

   // return to DOS

   exit(1);

   } // end if

// set the graphics mode to mode 13h

Set_Graphics_Mode(GRAPHICS_MODE13);

// create a double buffer

Create_Double_Buffer(200);

// create look up tables and load textures

if (!Initialize(argv[1]))
   {

   printf("\nError loading file %s",argv[1]);
   exit(1);

   } // end if

// install keyboard driver

Keyboard_Install_Driver();

// set scale of mountains

// draw the first frame

Draw_Terrain(play_x,
             play_y,
             play_height,
             play_ang,
             play_dist);

Display_Double_Buffer(double_buffer,0);

// get starting time

starting_time = Timer_Query();

// main event loop

while(!done)
     {

     // reset velocity

     speed = 0;

     // test if user is hitting keyboard

     if (keys_active)
        {
        // what is user trying to do

        // change viewing distance

        if (keyboard_state[MAKE_F])
           play_dist+=10;

        if (keyboard_state[MAKE_C])
           play_dist-=10;

        // change viewing height

        if (keyboard_state[MAKE_U])
           play_height+=10;

        if (keyboard_state[MAKE_D])
           play_height-=10;

        // change viewing position

        if (keyboard_state[MAKE_RIGHT])
            if ((play_ang+=ANGLE_5) >= ANGLE_360)
               play_ang-=ANGLE_360;

        if (keyboard_state[MAKE_LEFT])
            if ((play_ang-=ANGLE_5) < 0)
               play_ang+=ANGLE_360;

        // move foward

        if (keyboard_state[MAKE_UP])
           speed=10;

        // move backward

        if (keyboard_state[MAKE_DOWN])
           speed=-10;

        // exit demo

        if (keyboard_state[MAKE_ESC])
           done=1;

        // compute trajectory vector for this view angle

        play_dir_x = cos_look[play_ang];
        play_dir_y = -sin_look[play_ang];

        // translate viewpoint

        play_x     +=speed*play_dir_x;
        play_y     +=speed*play_dir_y;

        // draw tactical

        sprintf(buffer,"Height = %d Distance = %d     ",play_height,play_dist);
        Print_String_DB(0,0,10,buffer,0);

        sprintf(buffer,"Pos: X=%d, Y=%d     ",play_x,play_y);
        Print_String_DB(0,10,10,buffer,0);

        } // end if

     // draw the terrain

     Fill_Double_Buffer(0);

     Draw_Terrain(play_x,
                  play_y,
                  play_height,
                  play_ang,
                  play_dist);


     Display_Double_Buffer(double_buffer,0);

     // increment frame counter

     num_frames++;

     } // end while

// reset back to text mode

Set_Graphics_Mode(TEXT_MODE);

// remove the keyboard handler

Keyboard_Remove_Driver();

// get ending time and compute FPS

ending_time = Timer_Query();

cout << "\nFPS = " << 18*(float)num_frames/((float)(ending_time - starting_time));


} // end main



