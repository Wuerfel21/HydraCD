

Black Art of 3D Game Programming by Andre' LaMothe
32 Bit Watcom 10.x Versions

At long last I have got around to converting the majority of
the "Black Art of 3D Game Programming" C source code to 32 bit
protected mode. The target compiler is Watcom 10.x and the
target Dos Extender is Rational Systems Dos4G. There are both
C and C++ versions of the files, so you should simply be able
to include the header files, C/C++ files in your project and
compile away and everything should work.

Have Fun!

Andre' LaMothe


