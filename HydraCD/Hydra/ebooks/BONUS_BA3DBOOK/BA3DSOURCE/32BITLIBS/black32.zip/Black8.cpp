
// BLACK8.CPP - Library Module

// I N C L U D E S ///////////////////////////////////////////////////////////

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include <i86.h>
#include <conio.h>
#include <io.h>
#include <time.h>
#include <bios.h>
#include <dos.h>
#include "32bit.h"

#include "black3.h"
#include "black4.h"
#include "black8.h"

// G L O B A L S /////////////////////////////////////////////////////////////

int starting_time,  // these are used to compute the length of some event
     ending_time;

// F U N C T I O N S//////////////////////////////////////////////////////////

int Timer_Query(void)
{
// this function is used to record the current time

int *clock = (int *)0x0000046CL; // address of timer

return((int)*clock);

} // end Timer_Query

//////////////////////////////////////////////////////////////////////////////

void Timer_Program(int timer,unsigned int rate)
{

// this function re-programs the internal timer

// first program the timer to mode 2 - binary and data loading sequence of
// low byte then high byte

outp(TIMER_CONTROL, TIMER_SET_BITS);

// write least significant byte of the new rate to the counter register

outp(timer,LOW_BYTE(rate));

// and now the the most significant byte

outp(timer,HI_BYTE(rate));

} // end Timer_Program

///////////////////////////////////////////////////////////////////////////////

